To Deploy the app you can run


>> gcloud app deploy

Follow the prompt instructions to set it up

>> gcloud app browse

or Paste your url to new tab