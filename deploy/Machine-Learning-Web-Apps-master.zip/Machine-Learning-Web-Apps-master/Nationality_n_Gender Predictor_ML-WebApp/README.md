### Predicting Nationality and Gender Using Machine Learning

#### Web App

##### Requirements
+ flask
+ sklearn
+ material_bootstrap



### Nationality and Ethnicity Predictor
![](images/image2.png)


### Gender Predictor
![](images/image1.png)



#### By
+ Jesse E.Agbe(JCharis)
+ Jesus Saves@JCharisTech
+ J-Secur1ty