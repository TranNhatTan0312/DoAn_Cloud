### Gender Classifier ML App with Streamlit


#### Home
![](images/gc_app01.png)


#### Prediction
![](images/gc_app02.png)


#### Prediction
![](images/gc_app04.png)


#### By
+ Jesse E.Agbe(JCharis)
+ Jesus Saves@[JCharisTech](https://jcharistech.com)