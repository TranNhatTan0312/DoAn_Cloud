### DisplaCify App
#### Using Displacy in Flask

+ This is to demonstrate how to render Named Entity Recognition with Displacy in Flask

#### Requirements
+ Flask
+ Flask-Markdown
+ Spacy


#### Images
![](images/screenshot01.png)


![](images/screenshot02.png)



![](images/screenshot03.png)


#### By
+ Jesse E.Agbe(JCharis)
+ Jesus Saves@JCharisTech